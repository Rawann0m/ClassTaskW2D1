//
//  ListModel.swift
//  ClassTaskW2
//
//  Created by Rawan on 09/09/1446 AH.
//
import SwiftUI

// Model for list items
struct Item: Identifiable {
    let id = UUID()
    let image: String
    let name: String
}
