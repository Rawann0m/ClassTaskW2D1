//
//  ContentView.swift
//  ClassTaskW2
//
//  Created by Rawan on 09/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    //here is my list of items
    @State private var items: [Item] = [
        Item(image: "star", name: "Star"),
        Item(image: "heart", name: "Heart"),
        Item(image: "moon", name: "Moon")
    ]
    
    var body: some View {
        //using NavigationStack
        NavigationStack {
            List {
                ForEach(items) { item in
                    //im using NavigationLink to connect the detailview page
                    NavigationLink(destination: DetailView(item: item)) {
                        HStack {
                            //using hstack to show the labels next to the images
                            Image(systemName: item.image)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.purple)
                            
                            Text(item.name)
                                .font(.headline)
                        }
                        .padding(5)
                    }
                    .onTapGesture {
                        print("\(item.name) tapped!")
                    }
                }
                //using it to delete items
                .onDelete(perform: deleteItem)
            }
            .navigationTitle("Item List")
            //using the toolbar to show the plus sign to be able to add items by using the function additem
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: addItem) {
                        Image(systemName: "plus")
                            .foregroundColor(.purple)
                    }
                }
            }
        }
    }
    // here is my function to add a new item
    private func addItem() {
        //added animations
        withAnimation(.spring()) {
            items.append(Item(image: "star", name: "New Item"))
        }
    }
    
    // here is a function to remove items
    private func deleteItem(at offsets: IndexSet) {
        //added animations
        withAnimation(.easeInOut) {
            items.remove(atOffsets: offsets)
        }
    }
}

#Preview {
    ContentView()
}
