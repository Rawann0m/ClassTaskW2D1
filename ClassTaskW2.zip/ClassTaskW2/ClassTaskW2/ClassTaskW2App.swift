//
//  ClassTaskW2App.swift
//  ClassTaskW2
//
//  Created by Rawan on 09/09/1446 AH.
//

import SwiftUI

@main
struct ClassTaskW2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
