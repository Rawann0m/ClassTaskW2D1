//
//  DetailView.swift
//  ClassTaskW2
//
//  Created by Rawan on 09/09/1446 AH.
//
import SwiftUI

struct DetailView: View {
    let item: Item
    
    var body: some View {
        VStack {
            Image(systemName: item.image)
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .foregroundColor(.purple)
                .padding()
            
            Text(item.name)
                .font(.largeTitle)
                .bold()
        }
        .navigationTitle("Detail View")
    }
}
